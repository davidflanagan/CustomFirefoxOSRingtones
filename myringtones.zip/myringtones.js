var myringtones = {
  Marimba: 'sounds/marimba.ogg',
  Saxophone: 'sounds/saxophone.ogg',
  Bells: 'sounds/bells.ogg'
};

navigator.mozSetMessageHandler('activity', function(activity) {
  var player = new Audio();
  var selectedRadioButton = null;

  var container = document.getElementById('ringtones');
  for(var name in myringtones) {
    var url = myringtones[name];
    var label = document.createElement('label');
    var radioButton = document.createElement('input');
    radioButton.type = 'radio';
    radioButton.name = 'ringtones';
    radioButton.dataset.url = url;
    radioButton.dataset.name = name;
    radioButton.onchange = radioButtonChangeHandler;
    label.appendChild(document.createTextNode(name));
    label.appendChild(radioButton);
    container.appendChild(label);
  }

  document.getElementById('cancel').onclick = cancelHandler;
  document.getElementById('set').onclick = setHandler;

  function radioButtonChangeHandler(e) {
    var button = e.target;
    if (button.checked) {
      selectedRadioButton = button;
      player.src = button.dataset.url;
      player.play();
    }
  }

  function cancelHandler() {
    activity.postError('canceled');
  }

  function setHandler() {
    if (!selectedRadioButton)
      return;

    var xhr = new XMLHttpRequest();
    xhr.open('GET', selectedRadioButton.dataset.url);
    xhr.overrideMimeType('audio/ogg');
    xhr.responseType = 'blob';
    xhr.send();
    xhr.onload = function() {
      activity.postResult({
        blob: xhr.response,
        name: selectedRadioButton.dataset.name
      });
    }
  }
});
